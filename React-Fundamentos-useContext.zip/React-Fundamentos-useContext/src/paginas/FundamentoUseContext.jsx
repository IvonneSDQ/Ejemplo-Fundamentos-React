import React from 'react'
import Casa from '../components/contextFundamentos/Casa'

const FundamentoUseContext = () => {
  return (
    <Casa/>
  )
}

export default FundamentoUseContext