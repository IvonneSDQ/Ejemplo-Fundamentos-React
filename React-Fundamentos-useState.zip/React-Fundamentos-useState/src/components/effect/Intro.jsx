import React from 'react'

const Intro = () => {
  return (
    <div>Intro a useEffect</div>
  )
}

export default Intro