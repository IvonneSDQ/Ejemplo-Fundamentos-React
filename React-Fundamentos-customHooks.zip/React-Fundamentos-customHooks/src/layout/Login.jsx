import React from 'react'

import { Outlet } from 'react-router-dom'

const Login = () => 
{
  return (
    
    <div className='text-center'>
      <Outlet/>
    </div>

  )
}

export default Login