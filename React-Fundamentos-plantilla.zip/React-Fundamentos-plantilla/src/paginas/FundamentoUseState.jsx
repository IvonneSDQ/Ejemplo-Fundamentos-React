import React from 'react'
import Intro from '../components/state/Intro'

const FundamentoUseState = () => {
  return (
    <Intro/>
  )
}

export default FundamentoUseState