import React from 'react'

const Intro = () => {
  return (
    <div>Intro a useState</div>
  )
}

export default Intro